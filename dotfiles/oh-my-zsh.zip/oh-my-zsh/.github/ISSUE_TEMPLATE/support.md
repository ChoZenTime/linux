---
name: Support
about: Request support for any problem you're having with Oh My Zsh
labels: 'Type: support'

---

<!--
1. Look for similar issues already posted (including closed ones)
2. Include as much relevant information as possible
3. Try to make sure the issue is due to Oh My Zsh
-->
